/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import static classes.Environment.clock;
import static classes.Environment.icon;
import static classes.Environment.transmit;
import java.util.Random;
import javax.swing.JLabel;

public class Sensor implements Runnable {

    private int color;          // 0 - red, 1 - blue
    private int state;          // current state
    private final int[] status;       // 0 - sleeping, 1 - listening to reds, 2 - listening to blues, 3 - transmitting
    private final int time_to_sleep;
    private final int time_to_reds;
    private final int time_to_blues;
    private final int time_to_transmit;
    private final int size;
    private final int local_clock;
    private int reds = 0;       // reds near the sensor
    private int blues = 0;      // blues near the sensor
    private final int range;      // transmission range
    JLabel label;

    public Sensor(int c, int r) {

        color = c;
        range = r;
        label = new JLabel(icon[color]);

        Random rand = new Random();
        time_to_sleep = rand.nextInt(3) + 60;
        time_to_reds = rand.nextInt(3) + 3;
        time_to_blues = rand.nextInt(3) + 3;
        time_to_transmit = rand.nextInt(3) + 3;
        size = time_to_sleep + time_to_reds + time_to_blues + time_to_transmit;
        local_clock = rand.nextInt(size) + 1;
        state = local_clock;

        status = new int[size + 1];
        // 0 for sleep by default
        for (int i = time_to_sleep + 1; i <= time_to_reds + time_to_sleep; i++) {
            status[i] = 1;
        }
        for (int i = time_to_sleep + time_to_reds + 1; i <= time_to_blues + time_to_reds + time_to_sleep; i++) {
            status[i] = 2;
        }
        for (int i = size - time_to_transmit + 1; i <= size; i++) {
            status[i] = 3;
        }
    }

    JLabel getLabel() {
        return this.label;
    }

    void incColor(int c) {
        if (c == 0) {
            this.reds++;
        } else {
            this.blues++;
        }
    }

    public int getRange() {
        return this.range;
    }

    public int getColor() {
        return this.color;
    }

    int getState() {
        return status[state];
    }

    private void changeColor(int c) {
        this.color = c;
        this.label.setIcon(icon[c]);
    }

    @Override
    public void run() {
        state = (local_clock + clock) % (size + 1);
        if (status[state] == 3) {
            //System.out.println("REDS & BLUES: " + reds + " " + blues);
            if (blues > 0 || reds > 0) {
                double balance = (blues - reds + .0) / (blues + reds + .0);
                if (balance < -0.25 && color == 0) {
                    changeColor(1);
                }
                if (balance > 0.25 && color == 1) {
                    changeColor(0);
                }
                reds = 0;
                blues = 0;
                //System.out.println("BALANCE: " + balance);
            }
            transmit(this);
        }
    }
}
